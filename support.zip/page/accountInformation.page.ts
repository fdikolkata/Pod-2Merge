import { expect, Locator, Page } from "@playwright/test";
import { testData } from "../utils/testData";
import ElementUtil from "../utils/elements-utils";
import { pageElements } from "../utils/PageElements";

import { homedir } from "os";
import { promises } from "dns";

export class AccountInformation {
  private page: Page;

  private accountInformationUrl: string;
  private EnterAccountInformation: Locator;

  //Title ----------------------------
  private MrRadioButton: Locator;
  private MrsRadioButton: Locator;
  //Title End--------------------------------
  private NameField: Locator;
  private EmailField: Locator;
  private PasswordField: Locator;
  //Dob-----------------------------
  private days: Locator;
  private months: Locator;
  private years: Locator;
  //Dob End--------------------------------
  private NewsletterCheckBox: Locator;
  private SpecialOffersCheckBox: Locator;
  private FirstNameField: Locator;
  private LastNameField: Locator;
  private CompanyField: Locator;
  private AddressField: Locator;
  private Address2Field: Locator;
  private CountryField: Locator;
  private StateField: Locator;
  private CityField: Locator;
  private ZipcodeField: Locator;
  private MobileNumberField: Locator;
  private CreateAccountButton: Locator;
  private AccountInformationTestData: any;
  private EXPECTED_ACCOUNT_INFORMATION_TEXT: string;

  constructor(page: Page) {
    this.page = page;

    this.AccountInformationTestData = testData.accountInformation;
    // URL for the account information page
    this.accountInformationUrl =
      pageElements.AccountInformation.accountInformationUrl;

    // Locator for the "Enter Account Information" text
    this.EnterAccountInformation = page
      .locator(pageElements.AccountInformation.EnterAccountInformation)
      .first();

    // Title radio buttons
    this.MrRadioButton = page.locator(
      pageElements.AccountInformation.MrRadioButton
    );
    this.MrsRadioButton = page.locator(
      pageElements.AccountInformation.MrsRadioButton
    );

    // Form fields
    this.NameField = page.locator(pageElements.AccountInformation.NameField);
    this.EmailField = page.locator(pageElements.AccountInformation.EmailField);
    this.PasswordField = page.locator(
      pageElements.AccountInformation.PasswordField
    );

    // Date of birth dropdowns
    this.days = page.locator(pageElements.AccountInformation.days);
    this.months = page.locator(pageElements.AccountInformation.months);
    this.years = page.locator(pageElements.AccountInformation.years);

    // Checkboxes
    this.NewsletterCheckBox = page.locator(
      pageElements.AccountInformation.NewsletterCheckBox
    );
    this.SpecialOffersCheckBox = page.locator(
      pageElements.AccountInformation.SpecialOffersCheckBox
    );

    // Address fields
    this.FirstNameField = page.locator(
      pageElements.AccountInformation.FirstNameField
    );
    this.LastNameField = page.locator(
      pageElements.AccountInformation.LastNameField
    );
    this.CompanyField = page.locator(
      pageElements.AccountInformation.CompanyField
    );
    this.AddressField = page.locator(
      pageElements.AccountInformation.AddressField
    );
    this.Address2Field = page.locator(
      pageElements.AccountInformation.Address2Field
    );
    this.CountryField = page.locator(
      pageElements.AccountInformation.CountryField
    );
    this.StateField = page.locator(pageElements.AccountInformation.StateField);
    this.CityField = page.locator(pageElements.AccountInformation.CityField);
    this.ZipcodeField = page.locator(
      pageElements.AccountInformation.ZipcodeField
    );
    this.MobileNumberField = page.locator(
      pageElements.AccountInformation.MobileNumberField
    );

    // Button to create an account
    this.CreateAccountButton = page
      .locator(pageElements.AccountInformation.CreateAccountButton)
      .first();

    this.EXPECTED_ACCOUNT_INFORMATION_TEXT =
      pageElements.AccountInformation.EXPECTED_ACCOUNT_INFORMATION_TEXT;
  }

  async goto() {
    try {
      await this.page.waitForLoadState("networkidle");
      await this.page.goto(this.accountInformationUrl);
    } catch (error) {
      console.error(error);
    }
  }

  async verifyAccountInformationPage() {
    try {
      await this.page.waitForLoadState("networkidle");

      await this.page.waitForSelector(
        pageElements.AccountInformation.EnterAccountInformation,
        { state: "visible" }
      );
      await expect(this.EnterAccountInformation).toBeVisible();
      await expect(this.EnterAccountInformation).toHaveText(
        this.EXPECTED_ACCOUNT_INFORMATION_TEXT
      );
    } catch (error) {
      console.error(error);
    }
  }

  async VerifyUserNameIsAutoPopulated(Name: string) {
    try {
      expect(await this.NameField).toHaveValue(Name);
    } catch (error) {
      console.error(error);
    }
  }
  async VerifyUserEmailIsAutoPopulated(email: string) {
    try {
      expect(await this.EmailField).toHaveValue(email);
    } catch (error) {
      console.error(error);
    }
  }

  async FillDataAndCreateAccount() {
    //As this will be taking number of variables so we will fetch the data directly from the testData.json
    try {
      //Title ----------------------------
      if (testData.accountInformation.Title == "Mr") {
        await this.MrRadioButton.check();
      } else {
        await this.MrsRadioButton.check();
      }

      //Title End--------------------------------

      await this.PasswordField.fill(this.AccountInformationTestData.Password);
      await this.days.selectOption({
        label: this.AccountInformationTestData.Dob.Day,
      });
      await this.months.selectOption({
        label: this.AccountInformationTestData.Dob.Month,
      });
      await this.years.selectOption({
        label: this.AccountInformationTestData.Dob.Year,
      });
      await this.NewsletterCheckBox.check();
      await this.SpecialOffersCheckBox.check();
      await this.FirstNameField.fill(this.AccountInformationTestData.FirstName);
      await this.LastNameField.fill(this.AccountInformationTestData.LastName);
      await this.CompanyField.fill(this.AccountInformationTestData.Company);
      await this.AddressField.fill(this.AccountInformationTestData.Address);
      await this.Address2Field.fill(this.AccountInformationTestData.Address2);
      await this.CountryField.selectOption({
        label: this.AccountInformationTestData.Country,
      });
      await this.StateField.fill(this.AccountInformationTestData.State);
      await this.CityField.fill(this.AccountInformationTestData.City);
      await this.ZipcodeField.fill(this.AccountInformationTestData.ZipCode);
      await this.MobileNumberField.fill(
        this.AccountInformationTestData.MobileNumber
      );
      await this.CreateAccountButton.click();
    } catch (error) {
      console.error(error);
    }
  }
}
