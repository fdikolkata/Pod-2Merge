


export const testData = {

    "accountInformation":{
        "Mr": "Mr.", 
        "Mrs": "Mrs",  
        "Title": "Mr",
        "Dob": { "Day": "14", "Month": "April", "Year": "2000" },
        "FirstName": "Aman",
        "LastName": "Shah",
        "Company": "ltim",
        "Address": "503, B-Wing, GRANDURA",
        "Address2": "Opp. IDBI Bank, Baner-Road",
        "Country": "India",
        "State": "Maharashtra",
        "City": "Pune",
        "ZipCode": "411045",
        "MobileNumber": "919850005263",
        "Email": "aman@ltim.com",
        "Password": "aman@2024",
        "ConfirmPassword": "aman@2024"
},

   

}