import { Page } from "@playwright/test";
import { LoginPage } from "../page/Login.page";
import { SignUpPage } from "../page/Signup.page";
import { AccountInformation } from "../page/accountInformation.page";
import { pageElements } from "./PageElements";
import PropertiesReader from 'properties-reader';
import * as path from 'path';
// Use require for properties-reader
const PropertiesReader = require('properties-reader');
import { getEnvVariable } from '../envReader';

export class pageObjectManager {
    private page: Page;
    private loginPage: LoginPage;
    private signUpPage: SignUpPage;
    private accountInformation: AccountInformation;
    private signUpPageElements: any;
    private pageElements: typeof pageElements;

    constructor(page: Page) {
        this.page = page;
        this.loginPage = new LoginPage(this.page);
        this.signUpPage = new SignUpPage(this.page);
        this.accountInformation = new AccountInformation(this.page);
        this.pageElements = pageElements;
        this.signUpPageElements = PropertiesReader(path.resolve(__dirname, '../page/WebElements/SignUp.page.properties'));
    }

    getLoginPage(): LoginPage {
        return this.loginPage;
    }

    getPageElements(): typeof pageElements {
        return this.pageElements;
    }

    getSignUpPage(): SignUpPage {
        return this.signUpPage;
    }

    getSignUpPageProperties(key: string): string {
        return this.signUpPageElements.get(key);
    }

    getEnvVariable(key: string): string | undefined {
        return getEnvVariable(key);
    }
    getAccountInformation():AccountInformation{
        return this.accountInformation;
    }
}
