import { Given, When, Then, DataTable } from '@cucumber/cucumber';

Given(`The browser is launched and user navigates to the login page`, async function() {
    // [Given] Sets up the initial state of the system.
});

Then(`user should see the login page header as {string}`, async function(arg0: string) {
    // [Then] Describes the expected outcome or result of the scenario.
});

When(`user enters the username {string}`, async function(arg0: string) {
    // [When] Describes the action or event that triggers the scenario.
});

When(`user enters the password {string}`, async function(arg0: string) {
    // [When] Describes the action or event that triggers the scenario.
});

When(`user clicks on the login button`, async function() {
    // [When] Describes the action or event that triggers the scenario.
});

Then(`Verify that Logged in as {string} is visible`, async function(arg0: string) {
    // [Then] Describes the expected outcome or result of the scenario.
});

Then(`Verify that user is getting error message`, async function() {
    // [Then] Describes the expected outcome or result of the scenario.
});

Then(`Verify that the error message is as expected`, async function() {
    // [Then] Describes the expected outcome or result of the scenario.
});