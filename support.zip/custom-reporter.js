const { Reporter } = require('@playwright/test/reporter');
const open = require('open');
const path = require('path');

class CustomReporter extends Reporter {
  async onEnd() {
    try {
        
        const reportPath = path.resolve(__dirname, 'cucumber-report.html');
        await open(reportPath);
        console.log("reportPath",reportPath)
    } catch (error) {
        console.error(error);
    }
  }
}

module.exports = CustomReporter;
