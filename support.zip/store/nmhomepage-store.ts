import { makeAutoObservable } from 'mobx';

